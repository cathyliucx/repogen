# Copyright (c) Meta Platforms, Inc. and affiliates
"""Models package for data structures used in the vending machine."""
