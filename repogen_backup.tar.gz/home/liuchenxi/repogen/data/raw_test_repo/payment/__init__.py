# Copyright (c) Meta Platforms, Inc. and affiliates
"""Payment processing package for handling different payment methods."""
