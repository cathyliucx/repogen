# File: raw_test_repo/models/__init__.py

Models package for data structures used in the vending machine.
