"""Agents for the recursive wiki system."""
