"""Recursive Repo Wiki system.

All implementation lives under `agent/wiki`.
"""
